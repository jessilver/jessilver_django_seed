from django.apps import AppConfig


class DjangoSeedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jessilver_django_seed'
